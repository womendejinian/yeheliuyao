/**
 * 运行时绑定访问（仅服务端）—— D1 / KV 等 Workers 绑定入口，以及 Docker/Node 本地 SQLite 兼容层。
 *
 * Next(dev/Node) 默认没有 Workers 绑定；vinext/workerd 里通过 `cloudflare:workers` 取。
 * 在 Docker 部署环境下（设置 SQLITE_DB_PATH，例如 /app/data/liuyao.db），
 * 自动调用 Node 22 内置的 SQLite 模块模拟 Cloudflare D1 接口，实现服务端卦例持久化。
 */
import type { D1Like, D1PreparedStatement, D1Result } from './d1-types';

export interface RuntimeEnv {
  DB?: unknown;
  [key: string]: unknown;
}

const GLOBAL_DB_KEY = '__liuyao_node_sqlite_d1__';

async function getNodeSqliteD1(): Promise<D1Like | null> {
  const g = globalThis as Record<string, unknown>;
  if (g[GLOBAL_DB_KEY]) return g[GLOBAL_DB_KEY] as D1Like;

  if (typeof process === 'undefined' || !process.versions?.node) return null;
  const dbPath = process.env.SQLITE_DB_PATH?.trim() || '';
  if (!dbPath) return null;

  try {
    const sqliteSpec = ['node', 'sqlite'].join(':');
    const fsSpec = ['node', 'fs'].join(':');
    const pathSpec = ['node', 'path'].join(':');

    const sqliteMod = (await import(/* webpackIgnore: true */ /* @vite-ignore */ sqliteSpec)) as {
      DatabaseSync: new (location: string) => {
        exec(sql: string): void;
        prepare(sql: string): {
          run(...params: unknown[]): unknown;
          all(...params: unknown[]): unknown[];
          get(...params: unknown[]): unknown;
        };
      };
    };
    const fsMod = (await import(/* webpackIgnore: true */ /* @vite-ignore */ fsSpec)) as {
      mkdirSync(p: string, opts?: { recursive?: boolean }): void;
    };
    const pathMod = (await import(/* webpackIgnore: true */ /* @vite-ignore */ pathSpec)) as {
      dirname(p: string): string;
    };

    if (dbPath !== ':memory:') {
      fsMod.mkdirSync(pathMod.dirname(dbPath), { recursive: true });
    }
    const rawDb = new sqliteMod.DatabaseSync(dbPath);
    rawDb.exec('PRAGMA journal_mode = WAL;');
    rawDb.exec('PRAGMA busy_timeout = 5000;');

    const adapter: D1Like = {
      prepare(sql: string): D1PreparedStatement {
        let boundValues: unknown[] = [];
        const stmt: D1PreparedStatement = {
          bind(...values: unknown[]): D1PreparedStatement {
            boundValues = values.map((v) => (v === undefined ? null : v));
            return stmt;
          },
          async run(): Promise<unknown> {
            return rawDb.prepare(sql).run(...boundValues);
          },
          async all<T = Record<string, unknown>>(): Promise<D1Result<T>> {
            const rows = rawDb.prepare(sql).all(...boundValues) as T[];
            return { results: rows, success: true };
          },
          async first<T = unknown>(): Promise<T | null> {
            const row = rawDb.prepare(sql).get(...boundValues) as T | undefined;
            return row ?? null;
          },
        };
        return stmt;
      },
    };

    g[GLOBAL_DB_KEY] = adapter;
    return adapter;
  } catch (e) {
    console.warn('[db] Node SQLite 初始化失败，回退至内存/本地存储模式:', e);
    return null;
  }
}

export async function getRuntimeEnv(): Promise<RuntimeEnv | null> {
  try {
    const specifier = 'cloudflare:workers';
    const mod = (await import(/* webpackIgnore: true */ /* @vite-ignore */ specifier)) as {
      env?: RuntimeEnv;
    };
    if (mod?.env) return mod.env;
  } catch {
    /* 非 Cloudflare Workers 环境，继续尝试 Node SQLite */
  }

  const sqliteDb = await getNodeSqliteD1();
  if (sqliteDb) return { DB: sqliteDb };

  return null;
}
